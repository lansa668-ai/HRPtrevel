import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMarketingCopy = async (productName: string, features: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are a professional copywriter for a luxury brand app.
      Write a short, punchy, and persuasive product description (max 50 words) for a product named "${productName}".
      Key features: ${features}.
      Tone: Exclusive, exciting, and premium.
      Do not use markdown formatting.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Exclusive product for our premium members.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Experience luxury with this exclusive item.";
  }
};