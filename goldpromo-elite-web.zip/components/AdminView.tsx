import React, { useState } from 'react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell, YAxis, CartesianGrid } from 'recharts';
import { Plus, Trash2, Wand2, Bell, Users, ShoppingCart, TrendingUp, DollarSign, Search, MoreVertical } from 'lucide-react';
import { Product, AnalyticsData } from '../types';
import { generateMarketingCopy } from '../services/geminiService';

export const AdminDashboard: React.FC<{ analytics: AnalyticsData[] }> = ({ analytics }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Dashboard Overview</h2>
        <div className="flex gap-2">
            <select className="bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-2 text-sm text-zinc-300">
                <option>Last 7 Days</option>
                <option>Last 30 Days</option>
            </select>
            <button className="bg-gold-500 text-black px-4 py-2 rounded-lg text-sm font-bold hover:bg-gold-400">Export Report</button>
        </div>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
            { label: 'Total Users', value: '1,248', change: '+12%', icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Active Orders', value: '85', change: '-2%', icon: ShoppingCart, color: 'text-gold-500', bg: 'bg-gold-500/10' },
            { label: 'Total Revenue', value: '$45,200', change: '+8%', icon: DollarSign, color: 'text-green-500', bg: 'bg-green-500/10' },
            { label: 'Growth', value: '24%', change: '+4%', icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((stat, i) => (
            <div key={i} className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 hover:border-zinc-700 transition-colors">
                <div className="flex justify-between items-start mb-4">
                    <div className={`${stat.bg} ${stat.color} p-3 rounded-xl`}>
                        <stat.icon size={24} />
                    </div>
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${stat.change.startsWith('+') ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                        {stat.change}
                    </span>
                </div>
                <p className="text-zinc-400 text-sm font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-white mt-1">{stat.value}</p>
            </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
            <h3 className="text-lg font-bold mb-6">Traffic Analytics</h3>
            <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                <XAxis dataKey="name" stroke="#71717a" fontSize={12} tickLine={false} axisLine={false} dy={10} />
                <YAxis stroke="#71717a" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', borderRadius: '8px', color: '#fff' }}
                    cursor={{ fill: '#27272a' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
                    {analytics.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#f59e0b' : '#3f3f46'} />
                    ))}
                </Bar>
                </BarChart>
            </ResponsiveContainer>
            </div>
        </div>

        {/* Quick Actions Panel */}
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
            <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
            <div className="space-y-3">
                <button className="w-full bg-zinc-800/50 hover:bg-zinc-800 p-4 rounded-xl flex items-center gap-4 transition-all group border border-transparent hover:border-zinc-700">
                    <div className="bg-gold-500/20 p-2.5 rounded-lg text-gold-500 group-hover:bg-gold-500 group-hover:text-black transition-colors"><Bell size={20} /></div>
                    <div className="text-left flex-1">
                        <p className="font-bold text-sm text-zinc-200">Send Broadcast</p>
                        <p className="text-xs text-zinc-500">Push notification to all users</p>
                    </div>
                </button>
                <button className="w-full bg-zinc-800/50 hover:bg-zinc-800 p-4 rounded-xl flex items-center gap-4 transition-all group border border-transparent hover:border-zinc-700">
                    <div className="bg-blue-500/20 p-2.5 rounded-lg text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-colors"><Plus size={20} /></div>
                    <div className="text-left flex-1">
                        <p className="font-bold text-sm text-zinc-200">Create Voucher</p>
                        <p className="text-xs text-zinc-500">Generate new discount codes</p>
                    </div>
                </button>
                <button className="w-full bg-zinc-800/50 hover:bg-zinc-800 p-4 rounded-xl flex items-center gap-4 transition-all group border border-transparent hover:border-zinc-700">
                    <div className="bg-purple-500/20 p-2.5 rounded-lg text-purple-500 group-hover:bg-purple-500 group-hover:text-white transition-colors"><Wand2 size={20} /></div>
                    <div className="text-left flex-1">
                        <p className="font-bold text-sm text-zinc-200">AI Insights</p>
                        <p className="text-xs text-zinc-500">Analyze sales performance</p>
                    </div>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export const AdminProducts: React.FC<{ products: Product[], setProducts: React.Dispatch<React.SetStateAction<Product[]>> }> = ({ products, setProducts }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    category: '',
    image: 'https://picsum.photos/300/300'
  });

  const handleDelete = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const handleGenerateDescription = async () => {
    if (!newProduct.name) return;
    setIsGenerating(true);
    const copy = await generateMarketingCopy(newProduct.name, newProduct.category || "General product");
    setNewProduct(prev => ({ ...prev, description: copy }));
    setIsGenerating(false);
  };

  const handleSave = () => {
    if (!newProduct.name || !newProduct.price) return;
    const product: Product = {
      id: Date.now().toString(),
      name: newProduct.name,
      description: newProduct.description || '',
      price: Number(newProduct.price),
      promoPrice: newProduct.promoPrice ? Number(newProduct.promoPrice) : undefined,
      image: newProduct.image!,
      category: newProduct.category || 'General',
      isFlashSale: !!newProduct.isFlashSale
    };
    setProducts(prev => [product, ...prev]);
    setIsEditing(false);
    setNewProduct({ name: '', description: '', price: 0, category: '', image: 'https://picsum.photos/300/300' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 className="text-3xl font-bold">Product Management</h2>
            <p className="text-zinc-400">Manage your inventory and pricing.</p>
        </div>
        <div className="flex gap-3">
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                <input 
                    type="text" 
                    placeholder="Search inventory..." 
                    className="bg-zinc-900 border border-zinc-700 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:border-gold-500 focus:outline-none w-64"
                />
            </div>
            <button 
            onClick={() => setIsEditing(!isEditing)}
            className="bg-gold-500 text-black px-4 py-2.5 rounded-lg font-bold hover:bg-gold-400 transition-colors flex items-center gap-2"
            >
            {isEditing ? 'Cancel' : <><Plus size={20} /> Add Product</>}
            </button>
        </div>
      </div>

      {isEditing && (
        <div className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800 animate-in fade-in slide-in-from-top-4 shadow-2xl">
          <div className="flex justify-between items-center mb-6 border-b border-zinc-800 pb-4">
             <h3 className="text-xl font-bold">New Product Details</h3>
             <button onClick={() => setIsEditing(false)} className="text-zinc-500 hover:text-white">Close</button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
                <div className="space-y-2">
                    <label className="text-sm font-medium text-zinc-400">Product Name</label>
                    <input 
                        className="w-full bg-black border border-zinc-800 p-3 rounded-lg focus:border-gold-500 focus:outline-none transition-colors"
                        placeholder="e.g. Luxury Gold Watch"
                        value={newProduct.name}
                        onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                    />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-zinc-400">Base Price</label>
                        <input 
                        className="w-full bg-black border border-zinc-800 p-3 rounded-lg focus:border-gold-500 focus:outline-none"
                        placeholder="0"
                        type="number"
                        value={newProduct.price || ''}
                        onChange={e => setNewProduct({...newProduct, price: Number(e.target.value)})}
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-zinc-400">Promo Price</label>
                        <input 
                        className="w-full bg-black border border-zinc-800 p-3 rounded-lg focus:border-gold-500 focus:outline-none"
                        placeholder="Optional"
                        type="number"
                        value={newProduct.promoPrice || ''}
                        onChange={e => setNewProduct({...newProduct, promoPrice: Number(e.target.value)})}
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-zinc-400">Category</label>
                    <select 
                        className="w-full bg-black border border-zinc-800 p-3 rounded-lg focus:border-gold-500 focus:outline-none text-zinc-300"
                        value={newProduct.category}
                        onChange={e => setNewProduct({...newProduct, category: e.target.value})}
                    >
                        <option value="">Select Category</option>
                        <option value="Fashion">Fashion</option>
                        <option value="Food">Food & Beverage</option>
                        <option value="Service">Service</option>
                        <option value="Digital">Digital</option>
                    </select>
                </div>
            </div>

            <div className="space-y-4">
                <div className="space-y-2 h-full flex flex-col">
                    <div className="flex justify-between">
                        <label className="text-sm font-medium text-zinc-400">Description</label>
                        <button 
                            onClick={handleGenerateDescription}
                            disabled={isGenerating || !newProduct.name}
                            className="text-xs flex items-center gap-1 text-gold-500 hover:text-gold-400 disabled:opacity-50"
                        >
                            <Wand2 size={12} className={isGenerating ? "animate-spin" : ""} /> Generate with AI
                        </button>
                    </div>
                    <textarea 
                    className="w-full flex-1 bg-black border border-zinc-800 p-3 rounded-lg text-sm focus:border-gold-500 focus:outline-none resize-none"
                    placeholder="Product description..."
                    value={newProduct.description}
                    onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                    />
                </div>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-between border-t border-zinc-800 pt-6">
             <div className="flex items-center gap-3">
                <input 
                type="checkbox" 
                id="flash" 
                checked={newProduct.isFlashSale} 
                onChange={e => setNewProduct({...newProduct, isFlashSale: e.target.checked})}
                className="accent-gold-500 w-5 h-5 cursor-pointer"
                />
                <label htmlFor="flash" className="text-sm cursor-pointer select-none">Mark as Flash Sale Item</label>
            </div>
            <div className="flex gap-3">
                 <button onClick={() => setIsEditing(false)} className="px-6 py-2 rounded-lg hover:bg-zinc-800 transition-colors">Cancel</button>
                 <button onClick={handleSave} className="bg-white text-black font-bold px-8 py-2 rounded-lg hover:bg-zinc-200 transition-colors shadow-lg">
                    Save Product
                </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Table (Desktop) */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse">
            <thead className="bg-zinc-900/50 border-b border-zinc-800 text-xs uppercase text-zinc-500">
                <tr>
                    <th className="p-4 font-bold tracking-wider">Product</th>
                    <th className="p-4 font-bold tracking-wider">Category</th>
                    <th className="p-4 font-bold tracking-wider">Price</th>
                    <th className="p-4 font-bold tracking-wider">Status</th>
                    <th className="p-4 font-bold tracking-wider text-right">Actions</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
                {products.map(p => (
                    <tr key={p.id} className="hover:bg-zinc-800/50 transition-colors group">
                        <td className="p-4">
                            <div className="flex items-center gap-4">
                                <img src={p.image} alt="" className="w-12 h-12 rounded-lg object-cover bg-zinc-800" />
                                <div>
                                    <h4 className="font-bold text-white group-hover:text-gold-500 transition-colors">{p.name}</h4>
                                    <p className="text-zinc-500 text-xs line-clamp-1 max-w-[200px]">{p.description}</p>
                                </div>
                            </div>
                        </td>
                        <td className="p-4">
                            <span className="bg-zinc-800 text-zinc-300 px-2 py-1 rounded text-xs border border-zinc-700">{p.category}</span>
                        </td>
                        <td className="p-4">
                            <div className="flex flex-col">
                                {p.promoPrice ? (
                                    <>
                                        <span className="text-zinc-500 text-xs line-through">Rp {p.price.toLocaleString()}</span>
                                        <span className="text-gold-500 font-bold">Rp {p.promoPrice.toLocaleString()}</span>
                                    </>
                                ) : (
                                    <span className="text-white font-medium">Rp {p.price.toLocaleString()}</span>
                                )}
                            </div>
                        </td>
                        <td className="p-4">
                            {p.isFlashSale && (
                                <span className="flex items-center gap-1 text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-1 rounded w-fit">
                                    <TrendingUp size={12} /> FLASH SALE
                                </span>
                            )}
                        </td>
                        <td className="p-4 text-right">
                            <button onClick={() => handleDelete(p.id)} className="p-2 text-zinc-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors">
                                <Trash2 size={18} />
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
      </div>
    </div>
  );
};