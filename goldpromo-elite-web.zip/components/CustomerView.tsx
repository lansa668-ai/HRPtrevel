import React, { useState } from 'react';
import { Tag, Clock, MessageCircle, Star, Search, Filter, Copy, ArrowRight, ShoppingCart, Heart } from 'lucide-react';
import { Product, Voucher, User } from '../types';

// --- Components ---

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const discount = product.promoPrice 
    ? Math.round(((product.price - product.promoPrice) / product.price) * 100)
    : 0;

  const handleOrder = () => {
    const message = `Hi Admin, I want to order ${product.name}. Is it available?`;
    window.open(`https://wa.me/1234567890?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800 hover:border-gold-500/50 hover:shadow-xl hover:shadow-gold-900/10 transition-all duration-300 group flex flex-col h-full">
      <div className="relative aspect-square overflow-hidden bg-zinc-800">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
           {product.isFlashSale && (
            <div className="bg-gold-500 text-black text-xs font-bold px-2 py-1 rounded shadow-md flex items-center gap-1">
              <Clock size={12} /> FLASH
            </div>
          )}
          {discount > 0 && (
            <div className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded shadow-md">
              {discount}% OFF
            </div>
          )}
        </div>

        {/* Hover Action */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
            <button className="bg-white text-black p-2 rounded-full hover:bg-gold-500 transition-colors transform translate-y-4 group-hover:translate-y-0 duration-300">
                <Heart size={20} />
            </button>
            <button onClick={handleOrder} className="bg-white text-black p-2 rounded-full hover:bg-gold-500 transition-colors transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75">
                <ShoppingCart size={20} />
            </button>
        </div>
      </div>

      <div className="p-4 flex flex-col flex-1">
        <div className="mb-2">
            <span className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">{product.category}</span>
            <h3 className="font-bold text-white text-lg line-clamp-1 group-hover:text-gold-400 transition-colors">{product.name}</h3>
        </div>
        <p className="text-zinc-400 text-sm mb-4 line-clamp-2 flex-1">{product.description}</p>
        
        <div className="flex items-center justify-between mt-auto border-t border-zinc-800 pt-3">
          <div className="flex flex-col">
            {product.promoPrice ? (
              <>
                <p className="text-xs text-zinc-500 line-through">Rp {product.price.toLocaleString()}</p>
                <p className="text-gold-400 font-bold text-lg">Rp {product.promoPrice.toLocaleString()}</p>
              </>
            ) : (
              <p className="text-gold-400 font-bold text-lg">Rp {product.price.toLocaleString()}</p>
            )}
          </div>
          <button 
            onClick={handleOrder}
            className="flex items-center gap-2 bg-zinc-800 hover:bg-gold-500 hover:text-black text-white px-3 py-1.5 rounded-lg text-sm transition-all font-medium"
          >
            Order
          </button>
        </div>
      </div>
    </div>
  );
};

const VoucherCard: React.FC<{ voucher: Voucher }> = ({ voucher }) => {
  const [copied, setCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(voucher.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gradient-to-r from-zinc-900 to-zinc-800 border border-zinc-700 hover:border-gold-500/50 p-5 rounded-xl relative flex justify-between items-center group transition-all duration-300 hover:shadow-lg hover:shadow-gold-900/10">
      <div className="flex items-center gap-4">
        <div className="bg-gold-500/10 p-3 rounded-lg border border-gold-500/20 text-gold-500">
            <Tag size={24} />
        </div>
        <div>
            <h4 className="font-bold text-white text-xl">{voucher.discount} OFF</h4>
            <p className="text-zinc-400 text-sm">{voucher.description}</p>
            <p className="text-zinc-500 text-xs mt-1 font-mono">Expires: {voucher.expiryDate}</p>
        </div>
      </div>
      <div className="flex flex-col items-end gap-2">
        <button 
          onClick={copyCode}
          className="bg-black/40 hover:bg-gold-500 hover:text-black px-4 py-2 rounded-lg border border-dashed border-zinc-600 font-mono text-gold-400 transition-all flex items-center gap-2 group-hover:border-black/20"
        >
          {copied ? 'COPIED' : voucher.code}
          {!copied && <Copy size={14} />}
        </button>
      </div>
    </div>
  );
};

const LoyaltyCard: React.FC<{ user: User }> = ({ user }) => {
  const progress = (user.points % 1000) / 10; 

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-gold-600 via-gold-500 to-amber-700 rounded-2xl p-8 text-black shadow-2xl shadow-gold-900/20 max-w-2xl mx-auto">
      {/* Background Pattern */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-40 h-40 bg-black/10 rounded-full blur-3xl"></div>

      <div className="relative z-10 flex flex-col md:flex-row justify-between md:items-center gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
             <div className="bg-black/20 p-1.5 rounded text-black/70">
                <Star size={16} fill="currentColor" />
             </div>
             <p className="text-sm font-bold opacity-70 tracking-widest">LOYALTY PROGRAM</p>
          </div>
          <h2 className="text-4xl font-extrabold tracking-tight mb-2">{user.tier.toUpperCase()} TIER</h2>
          <p className="font-medium opacity-80">Member since 2023</p>
        </div>
        
        <div className="bg-white/20 backdrop-blur-md p-6 rounded-xl border border-white/10 min-w-[280px]">
          <div className="flex justify-between text-sm font-bold mb-2">
            <span>Current Balance</span>
            <span className="text-2xl">{user.points} <span className="text-xs font-normal opacity-70">pts</span></span>
          </div>
          <div className="h-3 bg-black/20 rounded-full overflow-hidden mb-2">
            <div 
              className="h-full bg-white shadow-lg rounded-full transition-all duration-1000 ease-out" 
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-xs font-medium opacity-70">
             <span>0</span>
             <span>1000 Goal</span>
          </div>
          <p className="text-xs mt-3 opacity-90 font-medium">Earn {1000 - (user.points % 1000)} more points to reach Platinum.</p>
        </div>
      </div>
    </div>
  );
};

// --- Pages ---

export const HomeTab: React.FC<{ products: Product[], vouchers: Voucher[], user: User }> = ({ products, vouchers, user }) => {
  const flashSaleProducts = products.filter(p => p.isFlashSale);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="relative h-[400px] rounded-3xl overflow-hidden bg-zinc-800 group shadow-2xl shadow-black/50">
        <img 
          src="https://picsum.photos/1200/600?grayscale" 
          alt="Big Sale" 
          className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-[2s]" 
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent"></div>
        <div className="absolute inset-0 flex flex-col justify-center px-12 max-w-2xl">
          <span className="bg-gold-500 text-black text-sm font-bold px-3 py-1 rounded w-fit mb-4 tracking-wider">LIMITED TIME OFFER</span>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
            Elevate Your <span className="text-gold-400">Lifestyle</span>
          </h2>
          <p className="text-zinc-300 text-lg mb-8 max-w-md leading-relaxed">
            Discover our premium collection with up to 50% off. Exclusive deals for Gold members start today.
          </p>
          <div className="flex gap-4">
             <button className="bg-white text-black px-8 py-3 rounded-xl text-base font-bold flex items-center gap-2 hover:bg-gold-400 hover:scale-105 transition-all">
                Shop Now <ArrowRight size={20} />
            </button>
            <button className="px-8 py-3 rounded-xl text-base font-bold text-white border border-zinc-600 hover:border-white transition-all">
                View Catalog
            </button>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="flex justify-center flex-wrap gap-4">
        {['All', 'Fashion', 'Food & Beverage', 'Services', 'Digital Goods', 'Accessories'].map((cat, i) => (
          <button 
            key={cat} 
            className={`px-6 py-2.5 rounded-full text-sm font-medium transition-all ${
                i === 0 
                ? 'bg-gold-500 text-black shadow-lg shadow-gold-500/20 hover:bg-gold-400' 
                : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Flash Sale Grid */}
      {flashSaleProducts.length > 0 && (
        <section>
          <div className="flex justify-between items-end mb-6 border-b border-zinc-800 pb-4">
            <div>
                <h3 className="text-2xl font-bold flex items-center gap-2 text-white">
                <Clock className="text-gold-500" size={28} /> Flash Sale
                </h3>
                <p className="text-zinc-400 text-sm mt-1">Hurry up! These deals expire soon.</p>
            </div>
            <div className="flex items-center gap-2 text-gold-500 font-mono bg-gold-950/30 px-4 py-2 rounded-lg border border-gold-900">
                <span className="font-bold">02</span>:
                <span className="font-bold">45</span>:
                <span className="font-bold">12</span>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {flashSaleProducts.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {/* Featured Vouchers */}
      <section>
        <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Tag className="text-gold-500" size={28} /> Curated Deals For You
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {vouchers.slice(0, 4).map(v => <VoucherCard key={v.id} voucher={v} />)}
        </div>
      </section>
    </div>
  );
};

export const CatalogTab: React.FC<{ products: Product[] }> = ({ products }) => {
  const [search, setSearch] = useState('');
  
  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-8">
      <div className="bg-zinc-900/50 p-8 rounded-2xl border border-zinc-800 backdrop-blur-sm sticky top-24 z-30 shadow-2xl">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
                <h2 className="text-3xl font-bold text-white">Catalog</h2>
                <p className="text-zinc-400 mt-1">Showing {filtered.length} premium items</p>
            </div>
            <div className="flex gap-3 w-full md:w-auto">
                <div className="relative flex-1 md:w-80">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                    <input 
                    type="text" 
                    placeholder="Search products..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full bg-black border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-sm focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all placeholder:text-zinc-600"
                    />
                </div>
                <button className="bg-zinc-800 border border-zinc-700 px-4 py-3 rounded-xl text-zinc-300 hover:text-white hover:border-zinc-500 flex items-center gap-2 font-medium transition-colors">
                    <Filter size={20} /> Filters
                </button>
            </div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {filtered.map(p => <ProductCard key={p.id} product={p} />)}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-20">
            <p className="text-zinc-500 text-lg">No products found matching "{search}"</p>
            <button onClick={() => setSearch('')} className="text-gold-500 hover:underline mt-2">Clear search</button>
        </div>
      )}
    </div>
  );
};

export const RewardsTab: React.FC<{ vouchers: Voucher[], user: User }> = ({ vouchers, user }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4">Your Membership Status</h2>
        <p className="text-zinc-400 mb-8">Unlock exclusive benefits by leveling up your tier.</p>
        <LoyaltyCard user={user} />
      </div>
      
      <div className="border-t border-zinc-800 pt-12">
        <h3 className="text-2xl font-bold mb-6">Available Vouchers</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {vouchers.map(v => <VoucherCard key={v.id} voucher={v} />)}
        </div>
      </div>
    </div>
  );
};

export const ProfileTab: React.FC<{ user: User }> = ({ user }) => {
  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-800 shadow-xl">
        {/* Header Cover */}
        <div className="h-32 bg-gradient-to-r from-zinc-800 to-zinc-900 relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        </div>
        
        <div className="px-8 pb-8">
            <div className="relative -mt-16 mb-6 flex justify-between items-end">
                <div className="relative">
                    <div className="w-32 h-32 bg-zinc-900 rounded-full overflow-hidden border-4 border-zinc-900 p-1">
                        <img src="https://picsum.photos/200" alt="User" className="w-full h-full rounded-full object-cover" />
                    </div>
                    <div className="absolute bottom-2 right-2 bg-gold-500 text-black p-1.5 rounded-full border-2 border-zinc-900" title="Gold Member">
                        <Star size={16} fill="black" />
                    </div>
                </div>
                <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-lg text-sm font-medium border border-zinc-700 transition-colors">
                    Edit Profile
                </button>
            </div>

            <h2 className="text-3xl font-bold text-white">{user.name}</h2>
            <p className="text-zinc-400">{user.email} • {user.phone}</p>
            
            <div className="grid grid-cols-2 gap-4 mt-8">
                <div className="bg-black/30 p-4 rounded-xl border border-zinc-800">
                    <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider mb-1">Total Points</p>
                    <p className="text-2xl font-bold text-gold-500">{user.points}</p>
                </div>
                <div className="bg-black/30 p-4 rounded-xl border border-zinc-800">
                    <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider mb-1">Member Tier</p>
                    <p className="text-2xl font-bold text-white">{user.tier}</p>
                </div>
            </div>

            <div className="mt-8 space-y-2">
                <button className="w-full px-4 py-4 text-left bg-zinc-800/50 hover:bg-zinc-800 rounded-xl transition-colors flex justify-between items-center group">
                    <span className="font-medium text-zinc-200">Shipping Addresses</span> 
                    <ArrowRight size={18} className="text-zinc-600 group-hover:text-white transition-colors" />
                </button>
                <button className="w-full px-4 py-4 text-left bg-zinc-800/50 hover:bg-zinc-800 rounded-xl transition-colors flex justify-between items-center group">
                    <span className="font-medium text-zinc-200">Order History</span> 
                    <ArrowRight size={18} className="text-zinc-600 group-hover:text-white transition-colors" />
                </button>
                <button className="w-full px-4 py-4 text-left bg-zinc-800/50 hover:bg-zinc-800 rounded-xl transition-colors flex justify-between items-center group">
                    <span className="font-medium text-zinc-200">Account Settings</span> 
                    <ArrowRight size={18} className="text-zinc-600 group-hover:text-white transition-colors" />
                </button>
            </div>

            <button className="w-full mt-8 bg-red-500/10 border border-red-900/50 text-red-500 py-3 rounded-xl font-medium hover:bg-red-500/20 transition-colors">
                Sign Out
            </button>
        </div>
      </div>
    </div>
  );
};