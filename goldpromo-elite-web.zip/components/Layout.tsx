import React from 'react';
import { Home, ShoppingBag, Gift, User, Settings, PieChart, Package, LogOut } from 'lucide-react';
import { UserRole } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  role: UserRole;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onRoleSwitch: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, role, activeTab, onTabChange, onRoleSwitch }) => {
  const navItems = role === UserRole.CUSTOMER 
    ? [
        { id: 'home', label: 'Home', icon: Home },
        { id: 'catalog', label: 'Catalog', icon: ShoppingBag },
        { id: 'rewards', label: 'Rewards', icon: Gift },
        { id: 'profile', label: 'Profile', icon: User },
      ]
    : [
        { id: 'admin-dash', label: 'Dashboard', icon: PieChart },
        { id: 'admin-products', label: 'Products', icon: Package },
        { id: 'admin-settings', label: 'Settings', icon: Settings },
      ];

  return (
    <div className="min-h-screen bg-onyx-950 text-white flex flex-col font-sans">
      {/* Web Header & Navigation */}
      <header className="sticky top-0 z-50 bg-onyx-900/95 backdrop-blur-md border-b border-zinc-800 shadow-lg shadow-gold-900/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => onTabChange(role === UserRole.CUSTOMER ? 'home' : 'admin-dash')}>
              <div className="w-10 h-10 bg-gradient-to-br from-gold-300 to-gold-600 rounded-xl flex items-center justify-center font-bold text-black text-xl shadow-gold-500/20 shadow-lg">
                G
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-gold-200 to-gold-500 bg-clip-text text-transparent leading-none">
                  GoldPromo
                </h1>
                <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
                  {role === UserRole.CUSTOMER ? 'Elite Store' : 'Admin Panel'}
                </span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`flex items-center gap-2 px-1 py-2 text-sm font-medium border-b-2 transition-all duration-200 ${
                    activeTab === item.id
                      ? 'border-gold-500 text-gold-500'
                      : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                  }`}
                >
                  <item.icon size={18} />
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-4">
              <button 
                onClick={onRoleSwitch}
                className="text-xs px-3 py-1.5 border border-zinc-700 rounded-full text-zinc-400 hover:text-white hover:border-zinc-500 transition-colors"
              >
                Switch to {role === UserRole.CUSTOMER ? 'Admin' : 'Store'}
              </button>
              {role === UserRole.CUSTOMER && (
                <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 overflow-hidden cursor-pointer hover:border-gold-500 transition-colors" onClick={() => onTabChange('profile')}>
                  <img src="https://picsum.photos/200" alt="User" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      {/* Mobile Bottom Nav (Visible only on small screens) */}
      <nav className="md:hidden fixed bottom-0 w-full bg-onyx-900 border-t border-zinc-800 pb-safe z-40">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => (
            <button 
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors ${activeTab === item.id ? 'text-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              <item.icon size={20} />
              <span className="text-[10px] mt-1 font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};