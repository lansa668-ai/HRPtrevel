export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  ADMIN = 'ADMIN'
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  promoPrice?: number;
  image: string;
  category: string;
  isFlashSale?: boolean;
}

export interface Voucher {
  id: string;
  code: string;
  discount: string;
  description: string;
  expiryDate: string;
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  points: number;
  tier: 'Silver' | 'Gold' | 'Platinum';
}

export interface AnalyticsData {
  name: string;
  value: number;
}