import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { HomeTab, CatalogTab, RewardsTab, ProfileTab } from './components/CustomerView';
import { AdminDashboard, AdminProducts } from './components/AdminView';
import { Product, Voucher, User, UserRole, AnalyticsData } from './types';

// Mock Data
const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Golden Hour Watch', description: 'Limited edition luxury timepiece with gold accents.', price: 5000000, promoPrice: 3500000, image: 'https://picsum.photos/300/300?random=1', category: 'Fashion', isFlashSale: true },
  { id: '2', name: 'Premium Leather Bag', description: 'Hand-stitched genuine leather.', price: 2000000, image: 'https://picsum.photos/300/300?random=2', category: 'Fashion' },
  { id: '3', name: 'Signature Coffee Bundle', description: '3 packs of our finest Arabica roast.', price: 450000, promoPrice: 300000, image: 'https://picsum.photos/300/300?random=3', category: 'Food' },
  { id: '4', name: 'Gold Member Pass', description: 'Exclusive access to VIP lounge.', price: 1000000, image: 'https://picsum.photos/300/300?random=4', category: 'Service' },
  { id: '5', name: 'Wireless Earbuds Pro', description: 'Noise cancelling with premium sound quality.', price: 1500000, promoPrice: 1200000, image: 'https://picsum.photos/300/300?random=5', category: 'Digital', isFlashSale: true },
];

const MOCK_VOUCHERS: Voucher[] = [
  { id: '1', code: 'WELCOME50', discount: '50%', description: 'New user discount', expiryDate: '30 Dec 2023' },
  { id: '2', code: 'FLASH10', discount: '10%', description: 'Extra discount on Flash Sale', expiryDate: '24h Left' },
];

const MOCK_USER: User = {
  id: 'u1',
  name: 'Andi Pratama',
  email: 'andi@example.com',
  phone: '08123456789',
  points: 750,
  tier: 'Silver'
};

const ANALYTICS_DATA: AnalyticsData[] = [
  { name: 'Mon', value: 400 },
  { name: 'Tue', value: 300 },
  { name: 'Wed', value: 600 },
  { name: 'Thu', value: 800 },
  { name: 'Fri', value: 500 },
  { name: 'Sat', value: 900 },
  { name: 'Sun', value: 700 },
];

const App: React.FC = () => {
  const [role, setRole] = useState<UserRole>(UserRole.CUSTOMER);
  const [activeTab, setActiveTab] = useState('home');
  
  // App State
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [vouchers, setVouchers] = useState<Voucher[]>(MOCK_VOUCHERS);

  // Handle Tab changes based on Role
  useEffect(() => {
    if (role === UserRole.ADMIN && !activeTab.startsWith('admin')) {
      setActiveTab('admin-dash');
    } else if (role === UserRole.CUSTOMER && activeTab.startsWith('admin')) {
      setActiveTab('home');
    }
  }, [role, activeTab]);

  const toggleRole = () => {
    setRole(prev => prev === UserRole.CUSTOMER ? UserRole.ADMIN : UserRole.CUSTOMER);
  };

  return (
    <Layout 
      role={role} 
      activeTab={activeTab} 
      onTabChange={setActiveTab}
      onRoleSwitch={toggleRole}
    >
      {/* Customer Views */}
      {role === UserRole.CUSTOMER && (
        <div className="animate-in fade-in duration-500">
          {activeTab === 'home' && <HomeTab products={products} vouchers={vouchers} user={MOCK_USER} />}
          {activeTab === 'catalog' && <CatalogTab products={products} />}
          {activeTab === 'rewards' && <RewardsTab vouchers={vouchers} user={MOCK_USER} />}
          {activeTab === 'profile' && <ProfileTab user={MOCK_USER} />}
        </div>
      )}

      {/* Admin Views */}
      {role === UserRole.ADMIN && (
        <div className="animate-in fade-in duration-500">
          {activeTab === 'admin-dash' && <AdminDashboard analytics={ANALYTICS_DATA} />}
          {activeTab === 'admin-products' && <AdminProducts products={products} setProducts={setProducts} />}
          {activeTab === 'admin-settings' && (
            <div className="text-center text-zinc-500 mt-20">
              <p>Global App Settings (Mock)</p>
              <p className="text-xs">Theme, Language, Notifications</p>
            </div>
          )}
        </div>
      )}
    </Layout>
  );
};

export default App;